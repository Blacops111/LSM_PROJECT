<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\OnlineClass;

class OnlineClassController extends Controller
{
    public function schedule(Request $request)
    {
        // Schedule class logic
    }
}
