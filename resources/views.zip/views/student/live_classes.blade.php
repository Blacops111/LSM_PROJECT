@extends('layouts.app')

@section('content')
@extends('layouts.app')

@section('content')
<div class="container mx-auto">
    <h1 class="text-2xl font-bold mb-4">Live Classes</h1>

    <table class="min-w-full mt-4">
        <thead>
            <tr>
                <th class="border px-4 py-2">Class Title</th>
                <th class="border px-4 py-2">Date & Time</th>
                <th class="border px-4 py-2">Join Link</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through live classes and display them here -->
        </tbody>
    </table>
</div>
@endsection

        <thead>
            <tr>
                <th class="border px-4 py-2">Class Title</th>
                <th class="border px-4 py-2">Date & Time</th>
                <th class="border px-4 py-2">Join Link</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through live classes and display them here -->
        </tbody>
    </table>
</div>
@endsection
