@extends('layouts.app')

@section('content')
@extends('layouts.app')

@section('content')
<div class="container mx-auto">
    <h1 class="text-2xl font-bold mb-4">Discussion Forums</h1>

    <table class="min-w-full mt-4">
        <thead>
            <tr>
                <th class="border px-4 py-2">Forum Title</th>
                <th class="border px-4 py-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through forums and display them here -->
        </tbody>
    </table>
</div>
@endsection

        <thead>
            <tr>
                <th class="border px-4 py-2">Forum Title</th>
                <th class="border px-4 py-2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through forums and display them here -->
        </tbody>
    </table>
</div>
@endsection
