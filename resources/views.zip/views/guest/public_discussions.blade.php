@extends('layouts.app')

@section('content')
@extends('layouts.app')

@section('content')
<div class="container mx-auto">
    <h1 class="text-2xl font-bold mb-4">Public Discussions</h1>

    <table class="min-w-full mt-4">
        <thead>
            <tr>
                <th class="border px-4 py-2">Discussion Title</th>
                <th class="border px-4 py-2">Created By</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through public discussions and display them here -->
        </tbody>
    </table>
</div>
@endsection

        <thead>
            <tr>
                <th class="border px-4 py-2">Discussion Title</th>
                <th class="border px-4 py-2">Created By</th>
            </tr>
        </thead>
        <tbody>
            <!-- Loop through public discussions and display them here -->
        </tbody>
    </table>
</div>
@endsection
