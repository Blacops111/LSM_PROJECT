@extends('layouts.app')

@section('content')
@extends('layouts.app')

@section('content')
<div class="container mx-auto">
    <h1 class="text-2xl font-bold mb-4">Preview Materials</h1>

    <p>Access limited free resources here.</p>
    <!-- Add links to preview materials -->

    <!-- Add links to preview materials -->
</div>
@endsection

@endsection
