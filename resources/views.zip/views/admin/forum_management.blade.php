@extends('layouts.app')

@section('content')
@extends('layouts.app')

@section('content')
<div class="container mx-auto">
    <h1 class="text-2xl font-bold mb-4">Discussion Forum Management</h1>

    <p>Manage forums and respond to queries from students.</p>
    <!-- Add forum management features here -->

    <!-- Add forum management features here -->
</div>
@endsection

@endsection
