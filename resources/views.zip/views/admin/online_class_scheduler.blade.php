@extends('layouts.app')

@section('content')
@extends('layouts.app')

@section('content')
<div class="container mx-auto">
    <h1 class="text-2xl font-bold mb-4">Online Class Scheduler</h1>

    <p>Integrate scheduling for online classes using Zoom or Google Meet.</p>
    <!-- Add scheduling features here -->

    <!-- Add scheduling features here -->
</div>
@endsection

@endsection
