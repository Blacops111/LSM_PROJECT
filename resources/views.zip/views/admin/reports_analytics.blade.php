@extends('layouts.app')

@section('content')
@extends('layouts.app')

@section('content')
<div class="container mx-auto">
    <h1 class="text-2xl font-bold mb-4">Reports & Analytics</h1>

    <p>Here you can view student performance trends and export reports.</p>
    <!-- Add charts and reports here -->

    <!-- Add charts and reports here -->
</div>
@endsection

@endsection
