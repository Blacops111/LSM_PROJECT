@extends('layouts.app')

@section('content')
<div class="container mx-auto">
    <h1 class="text-2xl font-bold mb-4">Welcome to the Learning Management System</h1>
    <p>Use the navigation to access courses, assignments, and more.</p>
</div>
@endsection
